import './style.css'
import { createIcons, icons } from 'lucide'
import { registerRoute, navigate, initRouter, onRouteChange } from './src/core/router.js'
import { initI18n } from './src/core/i18n.js'
import { createHeader, createFooter, attachHeaderEvents } from './src/core/ui.js'
import { renderHome } from './src/pages/home.js'
import { renderDashboard } from './src/pages/dashboard.js'
import { renderAssessment } from './src/pages/assessment.js'
import { renderRecommendations } from './src/pages/recommendations.js'
import { renderParent } from './src/pages/parent.js'
import { renderCompare } from './src/pages/compare.js'
import { renderRoadmap } from './src/pages/roadmap.js'
import { renderCourses } from './src/pages/courses.js'
import { renderReport } from './src/pages/report.js'

function refreshIcons() {
  createIcons({ icons })
}

function renderPage(pageRenderer) {
  return (app) => {
    app.innerHTML = `
      ${createHeader()}
      <main class="page-content" id="page-content"></main>
      ${createFooter()}
    `
    const content = document.getElementById('page-content')
    pageRenderer(content)
    refreshIcons()
    attachHeaderEvents(app)
  }
}

const pageRenderers = {
  home: renderHome,
  dashboard: renderDashboard,
  assessment: renderAssessment,
  recommendations: renderRecommendations,
  parent: renderParent,
  compare: renderCompare,
  roadmap: renderRoadmap,
  courses: renderCourses,
  report: renderReport,
}

const routes = {}
for (const [name, renderer] of Object.entries(pageRenderers)) {
  routes[name] = renderPage(renderer)
  registerRoute(name, routes[name])
}

function fullRender() {
  const app = document.getElementById('app')
  const currentRoute = app?.getAttribute('data-current-route') || 'home'
  const route = routes[currentRoute] || routes['home']
  route(app)
}

function init() {
  onRouteChange((route) => {
    const app = document.getElementById('app')
    if (app) app.setAttribute('data-current-route', route)
    fullRender()
  })

  initI18n(() => {
    fullRender()
  })

  initRouter()
}

document.addEventListener('DOMContentLoaded', init)
