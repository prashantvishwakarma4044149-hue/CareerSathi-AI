const STORAGE_KEY = 'careersaathi_data';

const defaultState = {
  profile: {
    name: '',
    age: '',
    email: '',
    phone: '',
    education: '',
    interests: [],
    skills: [],
    careerPreferences: '',
    budget: '',
    preferredLocation: '',
  },
  assessment: {
    answers: {},
    completed: false,
    results: null,
    timestamp: null,
  },
  comparison: [],
  roadmap: {
    careerId: null,
    milestones: {},
  },
  familyNotes: [],
  language: 'en',
};

let state = loadState();
const listeners = [];

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      return { ...defaultState, ...JSON.parse(raw) };
    }
  } catch (e) {
    // ignore
  }
  return { ...defaultState };
}

function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    // ignore
  }
}

export function getState() {
  return state;
}

export function setState(updates) {
  state = { ...state, ...updates };
  saveState();
  notify();
}

export function updateProfile(updates) {
  state = {
    ...state,
    profile: { ...state.profile, ...updates },
  };
  saveState();
  notify();
}

export function setAssessmentAnswers(answers) {
  state = {
    ...state,
    assessment: {
      ...state.assessment,
      answers,
    },
  };
  saveState();
}

export function setAssessmentResults(results) {
  state = {
    ...state,
    assessment: {
      ...state.assessment,
      completed: true,
      results,
      timestamp: Date.now(),
    },
  };
  saveState();
  notify();
}

export function resetAssessment() {
  state = {
    ...state,
    assessment: {
      answers: {},
      completed: false,
      results: null,
      timestamp: null,
    },
  };
  saveState();
  notify();
}

export function setComparison(careerIds) {
  state = { ...state, comparison: careerIds.slice(0, 3) };
  saveState();
  notify();
}

export function toggleComparison(careerId) {
  const current = [...state.comparison];
  const idx = current.indexOf(careerId);
  if (idx >= 0) {
    current.splice(idx, 1);
  } else {
    if (current.length >= 3) return false;
    current.push(careerId);
  }
  setComparison(current);
  return true;
}

export function setRoadmapCareer(careerId) {
  state = {
    ...state,
    roadmap: {
      careerId,
      milestones: {},
    },
  };
  saveState();
  notify();
}

export function toggleMilestone(step) {
  state = {
    ...state,
    roadmap: {
      ...state.roadmap,
      milestones: {
        ...state.roadmap.milestones,
        [step]: !state.roadmap.milestones[step],
      },
    },
  };
  saveState();
  notify();
}

export function addFamilyNote(note) {
  state = {
    ...state,
    familyNotes: [...state.familyNotes, { id: Date.now(), text: note, timestamp: new Date().toLocaleString() }],
  };
  saveState();
  notify();
}

export function removeFamilyNote(id) {
  state = {
    ...state,
    familyNotes: state.familyNotes.filter((n) => n.id !== id),
  };
  saveState();
  notify();
}

export function setLanguage(lang) {
  state = { ...state, language: lang };
  saveState();
  notify();
}

function notify() {
  listeners.forEach((fn) => fn(state));
}

export function subscribe(fn) {
  listeners.push(fn);
  return () => {
    const idx = listeners.indexOf(fn);
    if (idx >= 0) listeners.splice(idx, 1);
  };
}
