import { careers } from '../data/careers.js';
import { assessmentQuestions } from '../data/questions.js';

export function calculateRecommendations(answers) {
  const profile = buildProfile(answers);
  const scores = careers.map((career) => {
    const score = scoreCareer(career, profile, answers);
    return { career, score, matchPercent: Math.round(score.total), reasons: score.reasons };
  });
  scores.sort((a, b) => b.matchPercent - a.matchPercent);
  return scores;
}

function buildProfile(answers) {
  const weights = {};
  for (const q of assessmentQuestions) {
    const answer = answers[q.id];
    if (!answer) continue;

    const options = Array.isArray(answer)
      ? answer
      : [answer];

    for (const optVal of options) {
      const opt = q.options.find((o) => o.value === optVal);
      if (opt && opt.weights) {
        for (const [key, val] of Object.entries(opt.weights)) {
          weights[key] = (weights[key] || 0) + val;
        }
      }
    }
  }
  return weights;
}

function scoreCareer(career, profileWeights, answers) {
  const careerWeights = career.matchWeights || {};
  let totalMatch = 0;
  let maxPossible = 0;
  const reasons = [];

  for (const [key, careerWeight] of Object.entries(careerWeights)) {
    const profileWeight = profileWeights[key] || 0;
    maxPossible += careerWeight * 10;
    if (profileWeight > 0) {
      const matchVal = Math.min(profileWeight, 10) / 10 * careerWeight * 10;
      totalMatch += matchVal;
      if (profileWeight >= 5) {
        reasons.push({
          en: `Your profile shows strong alignment with ${humanizeKey(key)} work`,
          hi: `आपकी प्रोफ़ाइल ${humanizeKeyHi(key)} कार्य के साथ मजबूत तालमेल दिखाती है`,
        });
      }
    }
  }

  if (maxPossible === 0) maxPossible = 1;
  let matchPercent = Math.min((totalMatch / maxPossible) * 100, 98);

  const budgetAnswer = answers['budget'];
  if (budgetAnswer) {
    const budgetOpt = assessmentQuestions.find((q) => q.id === 'budget').options.find((o) => o.value === budgetAnswer);
    if (budgetOpt && budgetOpt.budgetMax !== undefined) {
      if (career.courseCostValue <= budgetOpt.budgetMax) {
        matchPercent = Math.min(matchPercent + 5, 99);
        reasons.push({
          en: `Course cost (${career.courseCost}) fits within your budget`,
          hi: `कोर्स लागत (${career.courseCost}) आपके बजट के भीतर है`,
        });
      } else {
        matchPercent = Math.max(matchPercent - 5, 30);
      }
    }
  }

  const goalAnswer = answers['goals'];
  if (goalAnswer === 'business' && career.matchWeights.entrepreneurship) {
    matchPercent = Math.min(matchPercent + 3, 99);
    reasons.push({
      en: 'This career offers strong entrepreneurship opportunities',
      hi: 'यह करियर मजबूत उद्यमिता अवसर प्रदान करता है',
    });
  }
  if (goalAnswer === 'job' && career.salaryRange) {
    reasons.push({
      en: 'Offers stable employment opportunities',
      hi: 'स्थिर रोजगार अवसर प्रदान करता है',
    });
  }

  matchPercent = Math.max(Math.round(matchPercent), 35);

  if (reasons.length === 0) {
    reasons.push({
      en: 'General alignment with your assessment profile',
      hi: 'आपकी आकलन प्रोफ़ाइल के साथ सामान्य तालमेल',
    });
  }

  return { total: matchPercent, reasons };
}

function humanizeKey(key) {
  const map = {
    practical: 'practical',
    technical: 'technical',
    hands_on: 'hands-on',
    field_work: 'field-work',
    indoor: 'indoor',
    outdoor: 'outdoor',
    creative: 'creative',
    entrepreneurship: 'entrepreneurial',
    people: 'people-oriented',
    empathy: 'caregiving',
    remote: 'remote work',
    desk_work: 'desk-based',
    detail: 'detail-oriented',
    communication: 'communication',
    problem_solving: 'problem-solving',
    theoretical: 'theoretical',
  };
  return map[key] || key;
}

function humanizeKeyHi(key) {
  const map = {
    practical: 'व्यावहारिक',
    technical: 'तकनीकी',
    hands_on: 'हाथों से काम',
    field_work: 'मैदानी कार्य',
    indoor: 'इनडोर',
    outdoor: 'आउटडोर',
    creative: 'रचनात्मक',
    entrepreneurship: 'उद्यमिता',
    people: 'लोगों के साथ',
    empathy: 'देखभाल',
    remote: 'रिमोट कार्य',
    desk_work: 'डेस्क आधारित',
    detail: 'विस्तार पर ध्यान',
    communication: 'संवाद',
    problem_solving: 'समस्या समाधान',
    theoretical: 'सैद्धांतिक',
  };
  return map[key] || key;
}
