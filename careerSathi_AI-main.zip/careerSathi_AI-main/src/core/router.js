let currentRoute = 'home';
const routes = {};
const routeListeners = [];

export function registerRoute(name, renderer) {
  routes[name] = renderer;
}

export function getRoute() {
  return currentRoute;
}

export function getRoutes() {
  return routes;
}

export function navigate(route) {
  if (routes[route]) {
    currentRoute = route;
    window.scrollTo({ top: 0, behavior: 'smooth' });
    routeListeners.forEach((fn) => fn(route));
  }
}

export function onRouteChange(fn) {
  routeListeners.push(fn);
}

export function initRouter() {
  routeListeners.forEach((fn) => fn(currentRoute));
}
