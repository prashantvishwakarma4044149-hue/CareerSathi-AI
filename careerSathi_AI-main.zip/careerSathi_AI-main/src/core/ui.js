import { t, isHindi } from './i18n.js';
import { careers } from '../data/careers.js';
import { navigate, getRoute } from './router.js';
import { getState, toggleComparison } from './store.js';
import { refreshIcons } from './icons.js';

export function createHeader() {
  const lang = isHindi() ? 'hi' : 'en';
  const navItems = [
    { route: 'home', icon: 'home', label: 'nav_home' },
    { route: 'dashboard', icon: 'layout-dashboard', label: 'nav_dashboard' },
    { route: 'assessment', icon: 'clipboard-list', label: 'nav_assessment' },
    { route: 'recommendations', icon: 'lightbulb', label: 'nav_recommendations' },
    { route: 'parent', icon: 'users', label: 'nav_parent' },
    { route: 'compare', icon: 'git-compare', label: 'nav_compare' },
    { route: 'roadmap', icon: 'map', label: 'nav_roadmap' },
    { route: 'courses', icon: 'search', label: 'nav_courses' },
    { route: 'report', icon: 'file-text', label: 'nav_report' },
  ];

  const current = getRoute();

  const navLinks = navItems
    .map(
      (item) => `
      <a class="nav-link ${current === item.route ? 'active' : ''}" data-route="${item.route}">
        <i data-lucide="${item.icon}"></i>
        <span>${t(item.label)}</span>
      </a>`
    )
    .join('');

  return `
    <header class="site-header">
      <div class="header-container">
        <div class="header-brand" data-route="home">
          <i data-lucide="graduation-cap" class="brand-icon"></i>
          <div class="brand-text">
            <span class="brand-name">${t('appName')}</span>
            <span class="brand-tagline">${t('appTagline')}</span>
          </div>
        </div>
        <nav class="header-nav" id="header-nav">
          ${navLinks}
        </nav>
        <div class="header-actions">
          <div class="lang-switcher">
            <button class="lang-btn ${lang === 'en' ? 'active' : ''}" data-lang="en">EN</button>
            <button class="lang-btn ${lang === 'hi' ? 'active' : ''}" data-lang="hi">हिं</button>
          </div>
        </div>
        <button class="mobile-menu-toggle" id="mobile-menu-toggle" aria-label="Menu">
          <i data-lucide="menu"></i>
        </button>
      </div>
      <nav class="mobile-nav" id="mobile-nav" style="display:none">
        ${navLinks}
      </nav>
    </header>
  `;
}

export function createFooter() {
  return `
    <footer class="site-footer">
      <div class="footer-container">
        <div class="footer-brand">
          <i data-lucide="graduation-cap"></i>
          <span>${t('appName')}</span>
        </div>
        <p class="footer-note">${t('footerNote')}</p>
        <div class="footer-links">
          <a data-route="assessment">${t('nav_assessment')}</a>
          <a data-route="courses">${t('nav_courses')}</a>
          <a data-route="report">${t('nav_report')}</a>
        </div>
      </div>
    </footer>
  `;
}

export function attachHeaderEvents(container) {
  container.querySelectorAll('[data-route]').forEach((el) => {
    el.addEventListener('click', (e) => {
      e.preventDefault();
      const route = el.getAttribute('data-route');
      if (route) {
        navigate(route);
        const mobileNav = document.getElementById('mobile-nav');
        if (mobileNav) mobileNav.style.display = 'none';
      }
    });
  });

  container.querySelectorAll('.lang-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      import('./i18n.js').then(({ changeLanguage }) => {
        changeLanguage(btn.getAttribute('data-lang'));
      });
    });
  });

  const mobileToggle = container.querySelector('#mobile-menu-toggle');
  const mobileNav = container.querySelector('#mobile-nav');
  if (mobileToggle && mobileNav) {
    mobileToggle.addEventListener('click', () => {
      mobileNav.style.display = mobileNav.style.display === 'none' ? 'flex' : 'none';
    });
  }
}

export function careerCardHTML(career, matchInfo) {
  const hi = isHindi();
  const name = hi ? career.nameHi : career.name;
  const sector = hi ? career.sectorHi : career.sector;
  const desc = hi ? career.descriptionHi : career.description;
  const matchPercent = matchInfo ? matchInfo.matchPercent : null;
  const matchBadge = matchPercent !== null ? `<div class="match-badge">${t('matchPercent')}: ${matchPercent}%</div>` : '';
  const skills = (hi ? career.skillsHi : career.skills).slice(0, 3).join(', ');

  const state = getState();
  const isInComparison = state.comparison.includes(career.id);

  return `
    <div class="career-card" data-career-id="${career.id}">
      ${matchBadge}
      <div class="career-card-icon">
        <i data-lucide="${career.icon}"></i>
      </div>
      <h3>${name}</h3>
      <span class="career-sector">${sector}</span>
      <p class="career-desc">${desc}</p>
      <div class="career-meta">
        <span><i data-lucide="clock"></i> ${career.courseDuration}</span>
        <span><i data-lucide="wallet"></i> ${career.courseCost}</span>
      </div>
      <div class="career-skills-preview">${skills}</div>
      <div class="career-card-actions">
        <button class="btn-primary btn-sm" data-action="details" data-career-id="${career.id}">${t('viewDetails')}</button>
        <button class="btn-outline btn-sm ${isInComparison ? 'active' : ''}" data-action="compare" data-career-id="${career.id}">
          <i data-lucide="${isInComparison ? 'check' : 'git-compare'}"></i> ${t('compare')}
        </button>
      </div>
    </div>
  `;
}

export function attachCareerCardEvents(container) {
  container.querySelectorAll('[data-action="details"]').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = btn.getAttribute('data-career-id');
      const career = careers.find((c) => c.id === id);
      if (career) showCareerModal(career);
    });
  });

  container.querySelectorAll('[data-action="compare"]').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = btn.getAttribute('data-career-id');
      toggleComparison(id);
    });
  });
}

export function showCareerModal(career) {
  const hi = isHindi();
  const name = hi ? career.nameHi : career.name;
  const sector = hi ? career.sectorHi : career.sector;
  const desc = hi ? career.descriptionHi : career.description;
  const skills = (hi ? career.skillsHi : career.skills).map((s) => `<li>${s}</li>`).join('');
  const certs = career.certifications.map((c) => `<li>${c}</li>`).join('');
  const pathways = career.careerPathways.map((p) => `<li>${p}</li>`).join('');
  const modes = career.learningModes.join(', ');

  const modal = document.createElement('div');
  modal.className = 'modal-overlay';
  modal.innerHTML = `
    <div class="modal career-modal">
      <button class="modal-close" id="modal-close"><i data-lucide="x"></i></button>
      <div class="modal-header">
        <div class="modal-icon"><i data-lucide="${career.icon}"></i></div>
        <div>
          <h2>${name}</h2>
          <span class="career-sector">${sector}</span>
        </div>
      </div>
      <p class="modal-desc">${desc}</p>
      <div class="modal-grid">
        <div class="modal-section">
          <h3><i data-lucide="target"></i> ${t('requiredSkills')}</h3>
          <ul class="tag-list">${skills}</ul>
        </div>
        <div class="modal-section">
          <h3><i data-lucide="award"></i> ${t('certifications')}</h3>
          <ul class="tag-list">${certs}</ul>
        </div>
        <div class="modal-section">
          <h3><i data-lucide="clock"></i> ${t('courseDuration')}</h3>
          <p>${career.courseDuration}</p>
        </div>
        <div class="modal-section">
          <h3><i data-lucide="wallet"></i> ${t('estimatedCost')}</h3>
          <p>${career.courseCost}</p>
        </div>
        <div class="modal-section">
          <h3><i data-lucide="trending-up"></i> ${t('careerPathways')}</h3>
          <ul class="path-list">${pathways}</ul>
        </div>
        <div class="modal-section">
          <h3><i data-lucide="book-open"></i> ${t('learningModes')}</h3>
          <p>${modes}</p>
        </div>
        <div class="modal-section">
          <h3><i data-lucide="rocket"></i> ${t('futureOpportunities')}</h3>
          <p>${career.futureOpportunities}</p>
        </div>
        <div class="modal-section">
          <h3><i data-lucide="banknote"></i> ${t('salaryRange')}</h3>
          <p>${career.salaryRange}</p>
        </div>
      </div>
      <div class="modal-actions">
        <button class="btn-primary" data-action="compare" data-career-id="${career.id}">
          <i data-lucide="git-compare"></i> ${t('compare')}
        </button>
        <button class="btn-outline" data-action="roadmap" data-career-id="${career.id}">
          <i data-lucide="map"></i> ${t('nav_roadmap')}
        </button>
      </div>
    </div>
  `;
  document.body.appendChild(modal);
  refreshIcons();

  modal.querySelector('#modal-close').addEventListener('click', () => modal.remove());
  modal.addEventListener('click', (e) => {
    if (e.target === modal) modal.remove();
  });

  modal.querySelector('[data-action="compare"]').addEventListener('click', () => {
    toggleComparison(career.id);
    modal.remove();
  });

  modal.querySelector('[data-action="roadmap"]').addEventListener('click', () => {
    import('../core/store.js').then(({ setRoadmapCareer }) => {
      setRoadmapCareer(career.id);
      modal.remove();
      navigate('roadmap');
    });
  });
}
