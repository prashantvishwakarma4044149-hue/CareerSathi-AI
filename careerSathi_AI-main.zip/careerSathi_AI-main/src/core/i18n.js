import { translations } from '../data/translations.js';
import { getState, setLanguage, subscribe } from './store.js';

export function t(key) {
  const lang = getState().language;
  const dict = translations[lang] || translations.en;
  const parts = key.split('.');
  let result = dict;
  for (const part of parts) {
    result = result?.[part];
    if (result === undefined) break;
  }
  if (result === undefined) {
    result = translations.en;
    for (const part of parts) {
      result = result?.[part];
      if (result === undefined) break;
    }
  }
  return result !== undefined ? result : key;
}

export function getLanguage() {
  return getState().language;
}

export function changeLanguage(lang) {
  setLanguage(lang);
}

export function isHindi() {
  return getState().language === 'hi';
}

let reRenderCallback = null;

export function initI18n(callback) {
  reRenderCallback = callback;
  subscribe(() => {
    if (reRenderCallback) reRenderCallback();
  });
}
