import { t, isHindi } from '../core/i18n.js';
import { getState, setRoadmapCareer, toggleMilestone } from '../core/store.js';
import { careers } from '../data/careers.js';

export function renderRoadmap(container) {
  const state = getState();
  const hi = isHindi();
  const careerId = state.roadmap.careerId;

  if (!careerId) {
    const assessmentResults = state.assessment.results;
    const suggested = assessmentResults?.[0]?.career?.id;

    container.innerHTML = `
      <div class="page-container">
        <div class="page-header">
          <h1><i data-lucide="map"></i> ${t('careerRoadmap')}</h1>
          <p>${t('selectCareer')}</p>
        </div>
        <div class="career-selector-grid">
          ${careers.map((c) => `
            <div class="career-select-card" data-career-id="${c.id}">
              <div class="select-card-icon"><i data-lucide="${c.icon}"></i></div>
              <span>${hi ? c.nameHi : c.name}</span>
            </div>
          `).join('')}
        </div>
        ${suggested ? `
          <div class="suggested-career">
            <p>${hi ? 'आपके आकलन के अनुसार सुझाया गया:' : 'Suggested from your assessment:'}</p>
            <button class="btn-primary" id="use-suggested" data-career-id="${suggested}">
              <i data-lucide="star"></i> ${hi ? 'शीर्ष अनुशंसा का उपयोग करें' : 'Use Top Recommendation'}
            </button>
          </div>
        ` : ''}
      </div>
    `;

    container.querySelectorAll('[data-career-id]').forEach((el) => {
      el.addEventListener('click', () => {
        setRoadmapCareer(el.getAttribute('data-career-id'));
        renderRoadmap(container);
      });
    });
    return;
  }

  const career = careers.find((c) => c.id === careerId);
  if (!career) return;

  const steps = [
    { key: 'career', icon: 'compass' },
    { key: 'course', icon: 'book-open' },
    { key: 'skill', icon: 'wrench' },
    { key: 'certification', icon: 'award' },
    { key: 'internship', icon: 'briefcase' },
    { key: 'employment', icon: 'rocket' },
  ];

  const milestones = state.roadmap.milestones || {};
  const completedCount = steps.filter((s) => milestones[s.key]).length;
  const progress = Math.round((completedCount / steps.length) * 100);

  container.innerHTML = `
    <div class="page-container">
      <div class="page-header">
        <h1><i data-lucide="map"></i> ${t('careerRoadmap')}</h1>
        <p>${hi ? 'व्यक्तिगत सीखने का रास्ता' : 'Your personalized learning path'}</p>
      </div>

      <div class="roadmap-selected">
        <div class="roadmap-career-info">
          <div class="roadmap-icon"><i data-lucide="${career.icon}"></i></div>
          <div>
            <h2>${hi ? career.nameHi : career.name}</h2>
            <span class="career-sector">${hi ? career.sectorHi : career.sector}</span>
          </div>
        </div>
        <button class="btn-outline btn-sm" id="change-career">
          <i data-lucide="repeat"></i> ${t('selectCareer')}
        </button>
      </div>

      <div class="roadmap-progress-bar">
        <div class="progress-info">
          <span>${t('progress')}: ${progress}%</span>
          <span>${completedCount}/${steps.length} ${t('completed')}</span>
        </div>
        <div class="progress-bar">
          <div class="progress-fill" style="width: ${progress}%"></div>
        </div>
      </div>

      <div class="roadmap-timeline">
        ${steps.map((step, idx) => {
          const isCompleted = milestones[step.key];
          const isPrevCompleted = idx === 0 || milestones[steps[idx - 1].key];
          const status = isCompleted ? 'completed' : (isPrevCompleted ? 'current' : 'pending');

          return `
            <div class="timeline-item ${status}">
              <div class="timeline-marker" data-step="${step.key}">
                ${isCompleted ? '<i data-lucide="check"></i>' : `<span class="marker-num">${idx + 1}</span>`}
              </div>
              <div class="timeline-content">
                <h3>${t('roadmapSteps.' + step.key)}</h3>
                <p>${t('roadmapStepDesc.' + step.key)}</p>
                ${idx === 1 ? `<div class="timeline-detail"><i data-lucide="clock"></i> ${career.courseDuration} | <i data-lucide="wallet"></i> ${career.courseCost}</div>` : ''}
                ${idx === 2 ? `<div class="timeline-detail"><i data-lucide="target"></i> ${(hi ? career.skillsHi : career.skills).join(', ')}</div>` : ''}
                ${idx === 3 ? `<div class="timeline-detail"><i data-lucide="award"></i> ${career.certifications.join(', ')}</div>` : ''}
                <button class="btn-sm ${isCompleted ? 'btn-outline' : 'btn-primary'} milestone-btn" data-step="${step.key}">
                  ${isCompleted ? t('completed') : t('markComplete')}
                </button>
              </div>
              ${idx < steps.length - 1 ? '<div class="timeline-connector"></div>' : ''}
            </div>
          `;
        }).join('')}
      </div>
    </div>
  `;

  document.getElementById('change-career').addEventListener('click', () => {
    setRoadmapCareer(null);
    renderRoadmap(container);
  });

  container.querySelectorAll('.milestone-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      toggleMilestone(btn.getAttribute('data-step'));
      renderRoadmap(container);
    });
  });
}
