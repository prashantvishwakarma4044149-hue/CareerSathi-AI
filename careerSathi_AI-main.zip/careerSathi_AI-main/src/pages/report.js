import { t, isHindi } from '../core/i18n.js';
import { getState } from '../core/store.js';
import { careers } from '../data/careers.js';

export function renderReport(container) {
  const state = getState();
  const hi = isHindi();
  const p = state.profile;
  const results = state.assessment.results || [];
  const comparisonCareers = state.comparison.map((id) => careers.find((c) => c.id === id)).filter(Boolean);
  const roadmapCareer = state.roadmap.careerId ? careers.find((c) => c.id === state.roadmap.careerId) : null;
  const roadmapSteps = ['career', 'course', 'skill', 'certification', 'internship', 'employment'];
  const milestones = state.roadmap.milestones || {};
  const notes = state.familyNotes;

  container.innerHTML = `
    <div class="page-container">
      <div class="page-header no-print-actions">
        <h1><i data-lucide="file-text"></i> ${t('careerReport')}</h1>
        <p>${hi ? 'अपना व्यापक करियर रिपोर्ट देखें और प्रिंट करें' : 'View and print your comprehensive career report'}</p>
        <div class="report-actions">
          <button class="btn-primary" id="print-report">
            <i data-lucide="printer"></i> ${t('printReport')}
          </button>
          <button class="btn-outline" id="export-pdf">
            <i data-lucide="download"></i> ${t('exportPdf')}
          </button>
        </div>
      </div>

      <div class="report-document" id="report-document">
        <div class="report-cover">
          <div class="report-cover-icon"><i data-lucide="graduation-cap"></i></div>
          <h1>${t('appName')}</h1>
          <h2>${t('careerReport')}</h2>
          <p class="report-date">${new Date().toLocaleDateString()}</p>
          <div class="demo-inline"><i data-lucide="info"></i> ${t('demoContent')}</div>
        </div>

        <div class="report-section">
          <h2 class="report-section-title"><i data-lucide="user"></i> ${t('studentProfile')}</h2>
          <div class="report-grid">
            <div class="report-item"><span class="ri-label">${t('fullName')}</span><span class="ri-value">${p.name || '-'}</span></div>
            <div class="report-item"><span class="ri-label">${t('age')}</span><span class="ri-value">${p.age || '-'}</span></div>
            <div class="report-item"><span class="ri-label">${t('email')}</span><span class="ri-value">${p.email || '-'}</span></div>
            <div class="report-item"><span class="ri-label">${t('phone')}</span><span class="ri-value">${p.phone || '-'}</span></div>
            <div class="report-item"><span class="ri-label">${t('educationDetails')}</span><span class="ri-value">${formatEducation(p.education, hi)}</span></div>
            <div class="report-item"><span class="ri-label">${t('interestCategories')}</span><span class="ri-value">${p.interests.join(', ') || '-'}</span></div>
            <div class="report-item"><span class="ri-label">${t('skillAssessment')}</span><span class="ri-value">${p.skills.join(', ') || '-'}</span></div>
            <div class="report-item"><span class="ri-label">${t('budgetPreferences')}</span><span class="ri-value">${formatBudget(p.budget, hi)}</span></div>
            <div class="report-item"><span class="ri-label">${t('preferredLocation')}</span><span class="ri-value">${p.preferredLocation || '-'}</span></div>
          </div>
        </div>

        <div class="report-section">
          <h2 class="report-section-title"><i data-lucide="clipboard-list"></i> ${t('skillAssessment')}</h2>
          ${state.assessment.completed ? `
            <p>${hi ? 'आकलन पूरा हुआ' : 'Assessment completed'} ${new Date(state.assessment.timestamp).toLocaleDateString()}</p>
            <div class="report-results">
              ${results.slice(0, 5).map((r) => {
                const career = r.career;
                return `
                  <div class="report-result-row">
                    <span class="rrr-name">${hi ? career.nameHi : career.name}</span>
                    <span class="rrr-sector">${hi ? career.sectorHi : career.sector}</span>
                    <span class="rrr-match">${r.matchPercent}%</span>
                  </div>
                `;
              }).join('')}
            </div>
          ` : `<p>${t('noAssessmentYet')}</p>`}
        </div>

        ${comparisonCareers.length > 0 ? `
          <div class="report-section">
            <h2 class="report-section-title"><i data-lucide="git-compare"></i> ${t('careerComparison')}</h2>
            <table class="report-table">
              <thead>
                <tr>
                  <th></th>
                  ${comparisonCareers.map((c) => `<th>${hi ? c.nameHi : c.name}</th>`).join('')}
                </tr>
              </thead>
              <tbody>
                <tr><td>${t('estimatedCost')}</td>${comparisonCareers.map((c) => `<td>${c.courseCost}</td>`).join('')}</tr>
                <tr><td>${t('courseDuration')}</td>${comparisonCareers.map((c) => `<td>${c.courseDuration}</td>`).join('')}</tr>
                <tr><td>${t('salaryRange')}</td>${comparisonCareers.map((c) => `<td>${c.salaryRange}</td>`).join('')}</tr>
                <tr><td>${t('certifications')}</td>${comparisonCareers.map((c) => `<td>${c.certifications.join(', ')}</td>`).join('')}</tr>
              </tbody>
            </table>
          </div>
        ` : ''}

        ${roadmapCareer ? `
          <div class="report-section">
            <h2 class="report-section-title"><i data-lucide="map"></i> ${t('careerRoadmap')}</h2>
            <p><strong>${hi ? 'चयनित करियर' : 'Selected Career'}:</strong> ${hi ? roadmapCareer.nameHi : roadmapCareer.name}</p>
            <div class="report-roadmap">
              ${roadmapSteps.map((step, idx) => `
                <div class="report-roadmap-step ${milestones[step] ? 'completed' : ''}">
                  <span class="rrs-num">${milestones[step] ? '✓' : idx + 1}</span>
                  <span class="rrs-label">${t('roadmapSteps.' + step)}</span>
                </div>
              `).join('')}
            </div>
          </div>
        ` : ''}

        ${notes.length > 0 ? `
          <div class="report-section">
            <h2 class="report-section-title"><i data-lucide="messages-square"></i> ${t('discussionSummary')}</h2>
            <div class="report-notes">
              ${notes.map((n) => `<div class="report-note"><p>${n.text}</p><span>${n.timestamp}</span></div>`).join('')}
            </div>
          </div>
        ` : ''}

        <div class="report-footer">
          <p>${t('footerNote')}</p>
        </div>
      </div>
    </div>
  `;

  document.getElementById('print-report').addEventListener('click', () => {
    window.print();
  });

  document.getElementById('export-pdf').addEventListener('click', () => {
    window.print();
  });
}

function formatEducation(edu, hi) {
  const map = {
    '8th': hi ? 'कक्षा 8 या उससे नीचे' : 'Class 8 or below',
    '10th': hi ? 'कक्षा 10' : 'Class 10',
    '12th': hi ? 'कक्षा 12' : 'Class 12',
    'graduate': hi ? 'स्नातक' : 'Graduate',
    'postgraduate': hi ? 'स्नातकोत्तर' : 'Post Graduate',
  };
  return map[edu] || '-';
}

function formatBudget(budget, hi) {
  const map = {
    'free': hi ? 'मुफ़्त (₹2,000 से कम)' : 'Free (under ₹2,000)',
    'low': hi ? 'कम (₹2,000–₹10,000)' : 'Low (₹2,000–₹10,000)',
    'medium': hi ? 'मध्यम (₹10,000–₹25,000)' : 'Medium (₹10,000–₹25,000)',
    'high': hi ? 'उच्च (₹25,000+)' : 'High (₹25,000+)',
  };
  return map[budget] || '-';
}
