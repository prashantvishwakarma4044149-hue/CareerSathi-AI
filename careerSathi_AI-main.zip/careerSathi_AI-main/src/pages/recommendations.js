import { t, isHindi } from '../core/i18n.js';
import { getState } from '../core/store.js';
import { navigate } from '../core/router.js';
import { careerCardHTML, attachCareerCardEvents } from '../core/ui.js';
import { careers } from '../data/careers.js';
import { refreshIcons } from '../core/icons.js';

export function renderRecommendations(container) {
  const state = getState();
  const hi = isHindi();

  if (!state.assessment.completed || !state.assessment.results) {
    container.innerHTML = `
      <div class="page-container">
        <div class="empty-page">
          <div class="empty-icon"><i data-lucide="clipboard-list"></i></div>
          <h2>${t('noAssessmentYet')}</h2>
          <p>${t('takeAssessmentPrompt')}</p>
          <button class="btn-primary btn-lg" id="go-assessment">
            <i data-lucide="arrow-right"></i> ${t('startAssessment')}
          </button>
        </div>
      </div>
    `;
    document.getElementById('go-assessment').addEventListener('click', () => navigate('assessment'));
    return;
  }

  const results = state.assessment.results;
  const top3 = results.slice(0, 3);
  const rest = results.slice(3);

  container.innerHTML = `
    <div class="page-container">
      <div class="page-header">
        <h1><i data-lucide="lightbulb"></i> ${t('recommendedForYou')}</h1>
        <p>${hi ? 'आपके आकलन के आधार पर व्यक्तिगत करियर अनुशंसाएं' : 'Personalized career recommendations based on your assessment'}</p>
        <div class="demo-inline"><i data-lucide="info"></i> ${t('demoContent')}</div>
      </div>

      <div class="recommendations-layout">
        <div class="top-recommendations">
          ${top3.map((r, idx) => renderTopCard(r, idx, hi)).join('')}
        </div>

        <div class="rest-recommendations">
          <h2 class="section-subtitle">${hi ? 'अन्य अनुशंसित करियर' : 'Other Recommended Careers'}</h2>
          <div class="careers-grid">
            ${rest.map((r) => careerCardHTML(r.career, r)).join('')}
          </div>
        </div>
      </div>
    </div>
  `;

  attachCareerCardEvents(container);

  container.querySelectorAll('[data-action="why"]').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = btn.getAttribute('data-career-id');
      const result = results.find((r) => r.career.id === id);
      if (result) showReasonsModal(result, hi);
    });
  });

  container.querySelectorAll('[data-action="roadmap"]').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = btn.getAttribute('data-career-id');
      import('../core/store.js').then(({ setRoadmapCareer }) => {
        setRoadmapCareer(id);
        navigate('roadmap');
      });
    });
  });
}

function renderTopCard(result, index, hi) {
  const career = result.career;
  const name = hi ? career.nameHi : career.name;
  const sector = hi ? career.sectorHi : career.sector;
  const desc = hi ? career.descriptionHi : career.description;
  const rank = index + 1;
  const reasons = result.reasons.slice(0, 2).map((r) => `<li>${hi ? r.hi : r.en}</li>`).join('');

  return `
    <div class="top-rec-card rank-${rank}">
      <div class="rank-badge">#${rank}</div>
      <div class="rec-match-ring">
        <svg viewBox="0 0 100 100">
          <circle cx="50" cy="50" r="42" fill="none" stroke="rgba(255,255,255,0.2)" stroke-width="8" />
          <circle cx="50" cy="50" r="42" fill="none" stroke="white" stroke-width="8"
            stroke-dasharray="${2 * Math.PI * 42}"
            stroke-dashoffset="${2 * Math.PI * 42 * (1 - result.matchPercent / 100)}"
            transform="rotate(-90 50 50)"
            stroke-linecap="round"
          />
        </svg>
        <div class="rec-match-percent">${result.matchPercent}%</div>
      </div>
      <div class="rec-icon"><i data-lucide="${career.icon}"></i></div>
      <h3>${name}</h3>
      <span class="career-sector">${sector}</span>
      <p class="rec-desc">${desc}</p>
      <div class="rec-reasons">
        <strong>${t('whyRecommended')}</strong>
        <ul>${reasons}</ul>
      </div>
      <div class="rec-meta">
        <span><i data-lucide="clock"></i> ${career.courseDuration}</span>
        <span><i data-lucide="wallet"></i> ${career.courseCost}</span>
      </div>
      <div class="rec-actions">
        <button class="btn-primary btn-sm" data-action="why" data-career-id="${career.id}">
          <i data-lucide="help-circle"></i> ${t('whyRecommended')}
        </button>
        <button class="btn-outline btn-sm" data-action="roadmap" data-career-id="${career.id}">
          <i data-lucide="map"></i> ${t('nav_roadmap')}
        </button>
      </div>
    </div>
  `;
}

function showReasonsModal(result, hi) {
  const career = result.career;
  const name = hi ? career.nameHi : career.name;
  const reasons = result.reasons.map((r) => `<li>${hi ? r.hi : r.en}</li>`).join('');
  const skills = (hi ? career.skillsHi : career.skills).map((s) => `<li>${s}</li>`).join('');

  const modal = document.createElement('div');
  modal.className = 'modal-overlay';
  modal.innerHTML = `
    <div class="modal">
      <button class="modal-close" id="reasons-close"><i data-lucide="x"></i></button>
      <div class="modal-header">
        <div class="modal-icon"><i data-lucide="${career.icon}"></i></div>
        <div>
          <h2>${name}</h2>
          <span class="match-percent">${result.matchPercent}% ${t('matchPercent')}</span>
        </div>
      </div>
      <div class="modal-section">
        <h3><i data-lucide="help-circle"></i> ${t('whyRecommended')}</h3>
        <ul class="reasons-list">${reasons}</ul>
      </div>
      <div class="modal-section">
        <h3><i data-lucide="target"></i> ${t('requiredSkills')}</h3>
        <ul class="tag-list">${skills}</ul>
      </div>
    </div>
  `;
  document.body.appendChild(modal);
  refreshIcons();

  modal.querySelector('#reasons-close').addEventListener('click', () => modal.remove());
  modal.addEventListener('click', (e) => {
    if (e.target === modal) modal.remove();
  });
}
