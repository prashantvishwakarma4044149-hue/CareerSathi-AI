import { t, isHindi } from '../core/i18n.js';
import { navigate } from '../core/router.js';
import { careers } from '../data/careers.js';
import { careerCardHTML, attachCareerCardEvents } from '../core/ui.js';
import { getState } from '../core/store.js';

export function renderHome(container) {
  const hi = isHindi();
  const featured = careers.slice(0, 6);

  const stats = [
    { icon: 'users', value: '15+', label: hi ? 'करियर पथ' : 'Career Paths' },
    { icon: 'book-open', value: '30+', label: hi ? 'प्रशिक्षण कोर्स' : 'Training Courses' },
    { icon: 'map-pin', value: '20+', label: hi ? 'शहर' : 'Cities' },
    { icon: 'languages', value: '2', label: hi ? 'भाषाएं' : 'Languages' },
  ];

  const howItWorks = [
    { icon: 'clipboard-list', title: hi ? '1. आकलन करें' : '1. Take Assessment', desc: hi ? 'AI-संचालित प्रश्नावली के 8 प्रश्नों का उत्तर दें' : 'Answer 8 questions in our AI-guided questionnaire' },
    { icon: 'lightbulb', title: hi ? '2. अनुशंसा पाएं' : '2. Get Recommendations', desc: hi ? 'मैचिंग प्रतिशत के साथ व्यक्तिगत करियर प्राप्त करें' : 'Receive personalized career matches with percentages' },
    { icon: 'users', title: hi ? '3. परिवार के साथ चर्चा' : '3. Discuss with Family', desc: hi ? 'माता-पिता के साथ करियर विकल्पों की तुलना करें' : 'Compare options together with your parents' },
    { icon: 'map', title: hi ? '4. रोडमैप बनाएं' : '4. Build Your Roadmap', desc: hi ? 'करियर चयन से रोजगार तक रोडमैप बनाएं' : 'Create a step-by-step roadmap to employment' },
  ];

  const testimonials = [
    { name: hi ? 'प्रिया शर्मा' : 'Priya Sharma', role: hi ? 'छात्रा, कक्षा 12' : 'Student, Class 12', text: hi ? 'CareerSaathi ने मुझे ब्यूटी और वेलनेस करियर चुनने में मदद की। मेरे माता-पिता भी सहमत हो गए!' : 'CareerSaathi helped me choose a career in Beauty & Wellness. My parents agreed too!' },
    { name: hi ? 'राहुल कुमार' : 'Rahul Kumar', role: hi ? 'छात्र, कक्षा 10' : 'Student, Class 10', text: hi ? 'आकलन के बाद मुझे इलेक्ट्रीशियन करियर सुझाया गया। रोडमैप बहुत स्पष्ट था।' : 'The assessment suggested Electrician as a career. The roadmap was very clear.' },
    { name: hi ? 'श्रीमती देवी' : 'Mrs. Devi', role: hi ? 'अभिभावक' : 'Parent', text: hi ? 'पैरेंट डैशबोर्ड से मुझे कोर्स फीस और सुरक्षा की जानकारी मिली। बहुत उपयोगी!' : 'The parent dashboard helped me understand course fees and safety. Very useful!' },
  ];

  const features = [
    { icon: 'clipboard-list', title: 'aiAssessment', desc: 'aiAssessmentDesc' },
    { icon: 'users', title: 'familySupport', desc: 'familySupportDesc' },
    { icon: 'git-compare', title: 'careerCompare', desc: 'careerCompareDesc' },
    { icon: 'map', title: 'roadmapFeature', desc: 'roadmapFeatureDesc' },
    { icon: 'search', title: 'courseFinder', desc: 'courseFinderDesc' },
    { icon: 'file-text', title: 'reportFeature', desc: 'reportFeatureDesc' },
  ];

  container.innerHTML = `
    <section class="hero">
      <div class="hero-bg">
        <div class="hero-content">
          <div class="hero-badge"><i data-lucide="sparkles"></i> ${t('appTagline')}</div>
          <h1 class="hero-title">${t('heroTitle')}</h1>
          <p class="hero-subtitle">${t('heroSubtitle')}</p>
          <div class="hero-actions">
            <button class="btn-primary btn-lg" id="hero-get-started">
              <i data-lucide="rocket"></i> ${t('getStarted')}
            </button>
            <button class="btn-outline btn-lg" id="hero-explore">
              <i data-lucide="compass"></i> ${t('exploreCareers')}
            </button>
          </div>
          <p class="hero-privacy"><i data-lucide="shield-check"></i> ${t('privacyNote')}</p>
        </div>
        <div class="hero-visual">
          <div class="hero-illustration">
            <div class="illustration-card illustration-student">
              <i data-lucide="graduation-cap"></i>
              <span>${hi ? 'छात्र' : 'Student'}</span>
            </div>
            <div class="illustration-card illustration-parent">
              <i data-lucide="users"></i>
              <span>${hi ? 'अभिभावक' : 'Parent'}</span>
            </div>
            <div class="illustration-connector">
              <i data-lucide="heart"></i>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="stats-section">
      <div class="container">
        <h2 class="section-title">${t('statsTitle')}</h2>
        <div class="stats-grid">
          ${stats.map((s) => `
            <div class="stat-card">
              <div class="stat-icon"><i data-lucide="${s.icon}"></i></div>
              <div class="stat-value">${s.value}</div>
              <div class="stat-label">${s.label}</div>
            </div>
          `).join('')}
        </div>
      </div>
    </section>

    <section class="how-section">
      <div class="container">
        <h2 class="section-title">${t('howItWorksTitle')}</h2>
        <div class="how-grid">
          ${howItWorks.map((step) => `
            <div class="how-card">
              <div class="how-icon"><i data-lucide="${step.icon}"></i></div>
              <h3>${step.title}</h3>
              <p>${step.desc}</p>
            </div>
          `).join('')}
        </div>
      </div>
    </section>

    <section class="features-section">
      <div class="container">
        <h2 class="section-title">${t('featuresTitle')}</h2>
        <div class="features-grid">
          ${features.map((f) => `
            <div class="feature-card">
              <div class="feature-icon"><i data-lucide="${f.icon}"></i></div>
              <h3>${t(f.title)}</h3>
              <p>${t(f.desc)}</p>
            </div>
          `).join('')}
        </div>
      </div>
    </section>

    <section class="featured-section">
      <div class="container">
        <h2 class="section-title">${t('featuredCareers')}</h2>
        <div class="careers-grid" id="featured-careers">
          ${featured.map((c) => careerCardHTML(c)).join('')}
        </div>
      </div>
    </section>

    <section class="testimonials-section">
      <div class="container">
        <div class="demo-badge"><i data-lucide="info"></i> ${t('demoContent')}</div>
        <h2 class="section-title">${t('testimonials')}</h2>
        <div class="testimonials-grid">
          ${testimonials.map((tm) => `
            <div class="testimonial-card">
              <div class="testimonial-quote"><i data-lucide="quote"></i></div>
              <p class="testimonial-text">"${tm.text}"</p>
              <div class="testimonial-author">
                <div class="author-avatar"><i data-lucide="user"></i></div>
                <div>
                  <div class="author-name">${tm.name}</div>
                  <div class="author-role">${tm.role}</div>
                </div>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    </section>
  `;

  document.getElementById('hero-get-started').addEventListener('click', () => navigate('assessment'));
  document.getElementById('hero-explore').addEventListener('click', () => navigate('recommendations'));
  attachCareerCardEvents(container);
}
