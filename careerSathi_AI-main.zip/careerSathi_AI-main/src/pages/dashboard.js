import { t, isHindi } from '../core/i18n.js';
import { getState, updateProfile } from '../core/store.js';
import { navigate } from '../core/router.js';
import { careers } from '../data/careers.js';

export function renderDashboard(container) {
  const state = getState();
  const hi = isHindi();
  const p = state.profile;

  const assessmentStatus = state.assessment.completed
    ? `<div class="status-badge status-success"><i data-lucide="check-circle"></i> ${hi ? 'पूर्ण' : 'Completed'} - ${state.assessment.results?.[0]?.matchPercent || 0}% ${t('topMatch')}</div>`
    : `<div class="status-badge status-warning"><i data-lucide="alert-circle"></i> ${t('noAssessmentYet')}</div>`;

  const topResults = state.assessment.results?.slice(0, 3) || [];
  const historyHTML = topResults.length > 0
    ? topResults.map((r) => {
        const career = careers.find((c) => c.id === r.career.id);
        return `
          <div class="history-item" data-career-id="${career.id}">
            <div class="history-icon"><i data-lucide="${career.icon}"></i></div>
            <div class="history-info">
              <span class="history-name">${hi ? career.nameHi : career.name}</span>
              <span class="history-sector">${hi ? career.sectorHi : career.sector}</span>
            </div>
            <div class="history-match">${r.matchPercent}%</div>
          </div>
        `;
      }).join('')
    : `<p class="empty-state">${t('takeAssessmentPrompt')}</p>`;

  const interestOptions = ['technology', 'healthcare', 'construction', 'beauty', 'agriculture', 'business', 'design', 'teaching'];
  const interestLabels = {
    technology: hi ? 'तकनीक' : 'Technology',
    healthcare: hi ? 'स्वास्थ्य सेवा' : 'Healthcare',
    construction: hi ? 'निर्माण' : 'Construction',
    beauty: hi ? 'सौंदर्य' : 'Beauty',
    agriculture: hi ? 'कृषि' : 'Agriculture',
    business: hi ? 'व्यापार' : 'Business',
    design: hi ? 'डिज़ाइन' : 'Design',
    teaching: hi ? 'शिक्षण' : 'Teaching',
  };

  const skillOptions = ['communication', 'technical', 'creative', 'physical', 'analytical', 'leadership'];
  const skillLabels = {
    communication: hi ? 'संवाद' : 'Communication',
    technical: hi ? 'तकनीकी' : 'Technical',
    creative: hi ? 'रचनात्मक' : 'Creative',
    physical: hi ? 'शारीरिक' : 'Physical',
    analytical: hi ? 'विश्लेषणात्मक' : 'Analytical',
    leadership: hi ? 'नेतृत्व' : 'Leadership',
  };

  container.innerHTML = `
    <div class="page-container">
      <div class="page-header">
        <h1><i data-lucide="layout-dashboard"></i> ${t('studentDashboard')}</h1>
        <p>${hi ? 'अपनी प्रोफ़ाइल और करियर यात्रा को ट्रैक करें' : 'Track your profile and career journey'}</p>
      </div>

      <div class="dashboard-layout">
        <div class="dashboard-main">
          <div class="card form-card">
            <h2><i data-lucide="user"></i> ${t('studentProfile')}</h2>
            <form id="profile-form" class="profile-form">
              <div class="form-row">
                <div class="form-group">
                  <label>${t('fullName')}</label>
                  <input type="text" name="name" value="${p.name || ''}" required placeholder="${hi ? 'अपना नाम दर्ज करें' : 'Enter your name'}" />
                </div>
                <div class="form-group">
                  <label>${t('age')}</label>
                  <input type="number" name="age" value="${p.age || ''}" min="14" max="60" placeholder="${hi ? 'आयु' : 'Age'}" />
                </div>
              </div>
              <div class="form-row">
                <div class="form-group">
                  <label>${t('email')}</label>
                  <input type="email" name="email" value="${p.email || ''}" placeholder="${hi ? 'ईमेल' : 'Email'}" />
                </div>
                <div class="form-group">
                  <label>${t('phone')}</label>
                  <input type="tel" name="phone" value="${p.phone || ''}" placeholder="${hi ? 'फ़ोन' : 'Phone'}" />
                </div>
              </div>
              <div class="form-group">
                <label>${t('educationDetails')}</label>
                <select name="education">
                  <option value="">${hi ? 'चुनें' : 'Select'}</option>
                  <option value="8th" ${p.education === '8th' ? 'selected' : ''}>${hi ? 'कक्षा 8 या उससे नीचे' : 'Class 8 or below'}</option>
                  <option value="10th" ${p.education === '10th' ? 'selected' : ''}>${hi ? 'कक्षा 10' : 'Class 10'}</option>
                  <option value="12th" ${p.education === '12th' ? 'selected' : ''}>${hi ? 'कक्षा 12' : 'Class 12'}</option>
                  <option value="graduate" ${p.education === 'graduate' ? 'selected' : ''}>${hi ? 'स्नातक' : 'Graduate'}</option>
                  <option value="postgraduate" ${p.education === 'postgraduate' ? 'selected' : ''}>${hi ? 'स्नातकोत्तर' : 'Post Graduate'}</option>
                </select>
              </div>
              <div class="form-group">
                <label>${t('interestCategories')}</label>
                <div class="checkbox-group">
                  ${interestOptions.map((opt) => `
                    <label class="checkbox-pill">
                      <input type="checkbox" name="interests" value="${opt}" ${p.interests.includes(opt) ? 'checked' : ''} />
                      <span>${interestLabels[opt]}</span>
                    </label>
                  `).join('')}
                </div>
              </div>
              <div class="form-group">
                <label>${t('skillAssessment')}</label>
                <div class="checkbox-group">
                  ${skillOptions.map((opt) => `
                    <label class="checkbox-pill">
                      <input type="checkbox" name="skills" value="${opt}" ${p.skills.includes(opt) ? 'checked' : ''} />
                      <span>${skillLabels[opt]}</span>
                    </label>
                  `).join('')}
                </div>
              </div>
              <div class="form-group">
                <label>${t('careerPreferences')}</label>
                <select name="careerPreferences">
                  <option value="">${hi ? 'चुनें' : 'Select'}</option>
                  ${careers.map((c) => `<option value="${c.id}" ${p.careerPreferences === c.id ? 'selected' : ''}>${hi ? c.nameHi : c.name}</option>`).join('')}
                </select>
              </div>
              <div class="form-row">
                <div class="form-group">
                  <label>${t('budgetPreferences')}</label>
                  <select name="budget">
                    <option value="">${hi ? 'चुनें' : 'Select'}</option>
                    <option value="free" ${p.budget === 'free' ? 'selected' : ''}>${hi ? 'मुफ़्त (₹2,000 से कम)' : 'Free (under ₹2,000)'}</option>
                    <option value="low" ${p.budget === 'low' ? 'selected' : ''}>${hi ? 'कम (₹2,000–₹10,000)' : 'Low (₹2,000–₹10,000)'}</option>
                    <option value="medium" ${p.budget === 'medium' ? 'selected' : ''}>${hi ? 'मध्यम (₹10,000–₹25,000)' : 'Medium (₹10,000–₹25,000)'}</option>
                    <option value="high" ${p.budget === 'high' ? 'selected' : ''}>${hi ? 'उच्च (₹25,000+)' : 'High (₹25,000+)'}</option>
                  </select>
                </div>
                <div class="form-group">
                  <label>${t('preferredLocation')}</label>
                  <input type="text" name="preferredLocation" value="${p.preferredLocation || ''}" placeholder="${hi ? 'शहर या ऑनलाइन' : 'City or Online'}" />
                </div>
              </div>
              <button type="submit" class="btn-primary">
                <i data-lucide="save"></i> ${t('save')}
              </button>
            </form>
          </div>
        </div>

        <div class="dashboard-sidebar">
          <div class="card sidebar-card">
            <h3><i data-lucide="clipboard-list"></i> ${t('skillAssessment')}</h3>
            ${assessmentStatus}
            <button class="btn-outline btn-block" id="go-assessment">
              <i data-lucide="arrow-right"></i> ${state.assessment.completed ? t('retakeAssessment') : t('startAssessment')}
            </button>
          </div>

          <div class="card sidebar-card">
            <h3><i data-lucide="history"></i> ${t('recommendationHistory')}</h3>
            <div class="history-list" id="history-list">
              ${historyHTML}
            </div>
          </div>

          <div class="card sidebar-card">
            <h3><i data-lucide="mic"></i> ${t('voiceAssistant')}</h3>
            <div class="voice-placeholder">
              <i data-lucide="mic"></i>
              <p>${t('voiceAssistantPlaceholder')}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;

  document.getElementById('profile-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const interests = formData.getAll('interests');
    const skills = formData.getAll('skills');
    updateProfile({
      name: formData.get('name'),
      age: formData.get('age'),
      email: formData.get('email'),
      phone: formData.get('phone'),
      education: formData.get('education'),
      interests,
      skills,
      careerPreferences: formData.get('careerPreferences'),
      budget: formData.get('budget'),
      preferredLocation: formData.get('preferredLocation'),
    });
    showSaveToast();
  });

  document.getElementById('go-assessment').addEventListener('click', () => navigate('assessment'));

  container.querySelectorAll('.history-item').forEach((item) => {
    item.addEventListener('click', () => {
      import('../core/store.js').then(({ setRoadmapCareer }) => {
        setRoadmapCareer(item.getAttribute('data-career-id'));
        navigate('roadmap');
      });
    });
  });
}

function showSaveToast() {
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = isHindi() ? 'प्रोफ़ाइल सहेजी गई!' : 'Profile saved!';
  document.body.appendChild(toast);
  setTimeout(() => toast.classList.add('show'), 10);
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 300);
  }, 2500);
}
