import { t, isHindi } from '../core/i18n.js';
import { courses, courseLocations } from '../data/courses.js';
import { careers, careerSectors } from '../data/careers.js';
import { refreshIcons } from '../core/icons.js';

export function renderCourses(container) {
  const hi = isHindi();
  const filters = { search: '', sector: '', location: '', mode: '', duration: '', budget: '' };

  function getFilteredCourses() {
    return courses.filter((course) => {
      const career = careers.find((c) => c.id === course.careerId);
      if (!career) return false;

      if (filters.search) {
        const searchLower = filters.search.toLowerCase();
        if (!course.name.toLowerCase().includes(searchLower) &&
            !course.institute.toLowerCase().includes(searchLower) &&
            !(hi ? career.nameHi : career.name).toLowerCase().includes(searchLower)) {
          return false;
        }
      }

      if (filters.sector && career.sector !== filters.sector) return false;
      if (filters.location && course.location !== filters.location) return false;
      if (filters.mode && course.mode !== filters.mode) return false;

      if (filters.duration) {
        const weeks = courseDurationWeeks(course.duration);
        if (filters.duration === 'short' && weeks > 12) return false;
        if (filters.duration === 'medium' && (weeks <= 12 || weeks > 26)) return false;
        if (filters.duration === 'long' && weeks <= 26) return false;
      }

      if (filters.budget) {
        if (filters.budget === 'free' && course.cost > 0) return false;
        if (filters.budget === 'low' && (course.cost <= 0 || course.cost > 5000)) return false;
        if (filters.budget === 'medium' && (course.cost <= 5000 || course.cost > 15000)) return false;
        if (filters.budget === 'high' && course.cost <= 15000) return false;
      }

      return true;
    });
  }

  function renderCoursesList() {
    const filtered = getFilteredCourses();
    const listEl = document.getElementById('courses-list');

    if (filtered.length === 0) {
      listEl.innerHTML = `<div class="empty-state">${t('noResults')}</div>`;
      return;
    }

    listEl.innerHTML = filtered.map((course) => {
      const career = careers.find((c) => c.id === course.careerId);
      return `
        <div class="course-card">
          <div class="course-header">
            <div class="course-icon"><i data-lucide="${career.icon}"></i></div>
            <div>
              <h3>${course.name}</h3>
              <span class="career-sector">${hi ? career.nameHi : career.name}</span>
            </div>
          </div>
          <div class="course-details">
            <div class="course-detail-item">
              <i data-lucide="building"></i>
              <span>${course.institute}</span>
            </div>
            <div class="course-detail-item">
              <i data-lucide="map-pin"></i>
              <span>${course.location}</span>
            </div>
            <div class="course-detail-item">
              <i data-lucide="${course.mode === 'online' ? 'wifi' : 'map-pin'}"></i>
              <span>${course.mode === 'online' ? t('online') : t('offline')}</span>
            </div>
            <div class="course-detail-item">
              <i data-lucide="clock"></i>
              <span>${course.duration}</span>
            </div>
            <div class="course-detail-item">
              <i data-lucide="wallet"></i>
              <span>${course.cost === 0 ? (hi ? 'मुफ़्त' : 'Free') : '₹' + course.cost.toLocaleString()}</span>
            </div>
            <div class="course-detail-item">
              <i data-lucide="star"></i>
              <span>${course.rating} / 5</span>
            </div>
            <div class="course-detail-item">
              <i data-lucide="users"></i>
              <span>${course.seats} ${t('seats')}</span>
            </div>
          </div>
        </div>
      `;
    }).join('');

    refreshIcons();
  }

  container.innerHTML = `
    <div class="page-container">
      <div class="page-header">
        <h1><i data-lucide="search"></i> ${t('nav_courses')}</h1>
        <p>${hi ? 'व्यावसायिक पाठ्यक्रम खोजें और फ़िल्टर करें' : 'Search and filter vocational courses'}</p>
        <div class="demo-inline"><i data-lucide="info"></i> ${t('demoContent')}</div>
      </div>

      <div class="courses-layout">
        <aside class="courses-filters">
          <div class="card filter-card">
            <h3><i data-lucide="filter"></i> ${t('applyFilters')}</h3>
            <div class="filter-group">
              <label>${t('sector')}</label>
              <select id="filter-sector">
                <option value="">${t('allSectors')}</option>
                ${careerSectors.map((s) => `<option value="${s}">${s}</option>`).join('')}
              </select>
            </div>
            <div class="filter-group">
              <label>${t('location')}</label>
              <select id="filter-location">
                <option value="">${t('allLocations')}</option>
                ${courseLocations.map((l) => `<option value="${l}">${l}</option>`).join('')}
              </select>
            </div>
            <div class="filter-group">
              <label>${t('mode')}</label>
              <select id="filter-mode">
                <option value="">${t('allModes')}</option>
                <option value="online">${t('online')}</option>
                <option value="offline">${t('offline')}</option>
              </select>
            </div>
            <div class="filter-group">
              <label>${t('duration')}</label>
              <select id="filter-duration">
                <option value="">${t('allDurations')}</option>
                <option value="short">${hi ? 'कम (3 महीने से कम)' : 'Short (under 3 months)'}</option>
                <option value="medium">${hi ? 'मध्यम (3-6 महीने)' : 'Medium (3-6 months)'}</option>
                <option value="long">${hi ? 'लंबी (6 महीने से अधिक)' : 'Long (over 6 months)'}</option>
              </select>
            </div>
            <div class="filter-group">
              <label>${t('budget')}</label>
              <select id="filter-budget">
                <option value="">${t('allBudgets')}</option>
                <option value="free">${hi ? 'मुफ़्त' : 'Free'}</option>
                <option value="low">${hi ? 'कम (₹5,000 तक)' : 'Low (up to ₹5,000)'}</option>
                <option value="medium">${hi ? 'मध्यम (₹5,000-₹15,000)' : 'Medium (₹5,000-₹15,000)'}</option>
                <option value="high">${hi ? 'उच्च (₹15,000+)' : 'High (₹15,000+)'}</option>
              </select>
            </div>
            <button class="btn-outline btn-block" id="reset-filters">
              <i data-lucide="rotate-ccw"></i> ${t('resetFilters')}
            </button>
          </div>
        </aside>

        <div class="courses-main">
          <div class="search-bar">
            <i data-lucide="search"></i>
            <input type="text" id="course-search" placeholder="${t('searchCourses')}" />
          </div>
          <div class="courses-list" id="courses-list">
          </div>
        </div>
      </div>
    </div>
  `;

  const searchInput = document.getElementById('course-search');
  searchInput.addEventListener('input', () => {
    filters.search = searchInput.value;
    renderCoursesList();
  });

  ['sector', 'location', 'mode', 'duration', 'budget'].forEach((key) => {
    const el = document.getElementById(`filter-${key}`);
    el.addEventListener('change', () => {
      filters[key] = el.value;
      renderCoursesList();
    });
  });

  document.getElementById('reset-filters').addEventListener('click', () => {
    filters.search = '';
    filters.sector = '';
    filters.location = '';
    filters.mode = '';
    filters.duration = '';
    filters.budget = '';
    searchInput.value = '';
    ['sector', 'location', 'mode', 'duration', 'budget'].forEach((key) => {
      document.getElementById(`filter-${key}`).value = '';
    });
    renderCoursesList();
  });

  renderCoursesList();
}

function courseDurationWeeks(duration) {
  if (duration.includes('year')) {
    return parseInt(duration) * 52;
  }
  if (duration.includes('month')) {
    return parseInt(duration) * 4;
  }
  if (duration.includes('week')) {
    return parseInt(duration);
  }
  return 4;
}
