import { t, isHindi } from '../core/i18n.js';
import { getState, setAssessmentAnswers, setAssessmentResults, resetAssessment } from '../core/store.js';
import { assessmentQuestions } from '../data/questions.js';
import { calculateRecommendations } from '../core/assessment-engine.js';
import { navigate } from '../core/router.js';
import { refreshIcons } from '../core/icons.js';

export function renderAssessment(container) {
  const state = getState();
  const hi = isHindi();
  let currentStep = 0;
  let answers = { ...state.assessment.answers };

  if (state.assessment.completed) {
    renderCompletedState(container, state, hi);
    return;
  }

  renderQuestion(container, currentStep, answers, hi);

  function renderQuestion(container, step, answers, hi) {
    const q = assessmentQuestions[step];
    const total = assessmentQuestions.length;
    const progress = ((step) / total) * 100;

    const isMulti = q.type === 'multi';
    const selectedValues = answers[q.id] || (isMulti ? [] : null);

    const optionsHTML = q.options.map((opt) => {
      const isSelected = isMulti
        ? (selectedValues || []).includes(opt.value)
        : selectedValues === opt.value;
      const label = hi ? opt.labelHi : opt.label;
      return `
        <label class="assessment-option ${isSelected ? 'selected' : ''}" data-value="${opt.value}">
          <span class="option-check">
            <i data-lucide="${isMulti ? 'check-square' : 'circle-dot'}"></i>
          </span>
          <span class="option-label">${label}</span>
        </label>
      `;
    }).join('');

    container.innerHTML = `
      <div class="page-container">
        <div class="assessment-wrapper">
          <div class="assessment-header">
            <h1><i data-lucide="clipboard-list"></i> ${t('aiAssessment')}</h1>
            <p>${hi ? '8 सवालों का उत्तर दें और व्यक्तिगत करियर अनुशंसा पाएं' : 'Answer 8 questions to get personalized career recommendations'}</p>
          </div>

          <div class="assessment-progress">
            <div class="progress-bar">
              <div class="progress-fill" style="width: ${progress}%"></div>
            </div>
            <span class="progress-text">${t('step')} ${step + 1} ${t('of')} ${total}</span>
          </div>

          <div class="assessment-card" id="assessment-card">
            <div class="question-section">
              <h2 class="question-text">${hi ? q.questionHi : q.question}</h2>
              ${isMulti ? `<p class="question-hint">${hi ? 'एक से अधिक चुन सकते हैं' : 'You can select multiple'}</p>` : ''}
            </div>
            <div class="options-list" id="options-list">
              ${optionsHTML}
            </div>
          </div>

          <div class="assessment-nav">
            <button class="btn-outline" id="btn-back" ${step === 0 ? 'disabled' : ''}>
              <i data-lucide="arrow-left"></i> ${t('back')}
            </button>
            <span class="nav-step">${step + 1} / ${total}</span>
            ${step < total - 1 ? `
              <button class="btn-primary" id="btn-next" ${!isAnswered(q, answers) ? 'disabled' : ''}>
                ${t('next')} <i data-lucide="arrow-right"></i>
              </button>
            ` : `
              <button class="btn-primary btn-success" id="btn-submit" ${!isAnswered(q, answers) ? 'disabled' : ''}>
                <i data-lucide="check"></i> ${t('submit')}
              </button>
            `}
          </div>
        </div>
      </div>
    `;

    refreshIcons();

    attachEvents(step, q, answers, hi);
  }

  function isAnswered(q, answers) {
    const a = answers[q.id];
    if (!a) return false;
    if (q.type === 'multi') return a.length > 0;
    return !!a;
  }

  function attachEvents(step, q, answers, hi) {
    const optionsList = document.getElementById('options-list');
    const isMulti = q.type === 'multi';

    optionsList.querySelectorAll('.assessment-option').forEach((opt) => {
      opt.addEventListener('click', () => {
        const value = opt.getAttribute('data-value');
        if (isMulti) {
          const current = answers[q.id] || [];
          const idx = current.indexOf(value);
          if (idx >= 0) {
            current.splice(idx, 1);
          } else {
            current.push(value);
          }
          answers[q.id] = current;
        } else {
          answers[q.id] = value;
        }
        setAssessmentAnswers(answers);
        renderQuestion(container, step, answers, hi);
      });
    });

    const btnBack = document.getElementById('btn-back');
    const btnNext = document.getElementById('btn-next');
    const btnSubmit = document.getElementById('btn-submit');

    if (btnBack) {
      btnBack.addEventListener('click', () => {
        if (step > 0) {
          currentStep = step - 1;
          renderQuestion(container, currentStep, answers, hi);
        }
      });
    }

    if (btnNext) {
      btnNext.addEventListener('click', () => {
        if (isAnswered(q, answers) && step < assessmentQuestions.length - 1) {
          currentStep = step + 1;
          renderQuestion(container, currentStep, answers, hi);
        }
      });
    }

    if (btnSubmit) {
      btnSubmit.addEventListener('click', () => {
        if (isAnswered(q, answers)) {
          const results = calculateRecommendations(answers);
          setAssessmentResults(results);
          renderCompletedState(container, getState(), hi);
        }
      });
    }
  }
}

function renderCompletedState(container, state, hi) {
  const topMatch = state.assessment.results?.[0];
  const topCareer = topMatch ? topMatch.career : null;

  container.innerHTML = `
    <div class="page-container">
      <div class="assessment-complete">
        <div class="complete-icon">
          <i data-lucide="check-circle"></i>
        </div>
        <h1>${t('assessmentComplete')}</h1>
        ${topCareer ? `
          <p class="complete-subtitle">
            ${t('topMatch')}: <strong>${hi ? topCareer.nameHi : topCareer.name}</strong> (${topMatch.matchPercent}%)
          </p>
        ` : ''}
        <div class="complete-actions">
          <button class="btn-primary btn-lg" id="go-recommendations">
            <i data-lucide="lightbulb"></i> ${t('viewRecommendations')}
          </button>
          <button class="btn-outline btn-lg" id="retake">
            <i data-lucide="refresh-cw"></i> ${t('retakeAssessment')}
          </button>
        </div>
      </div>
    </div>
  `;

  document.getElementById('go-recommendations').addEventListener('click', () => navigate('recommendations'));
  document.getElementById('retake').addEventListener('click', () => {
    resetAssessment();
    renderAssessment(container);
  });
}
