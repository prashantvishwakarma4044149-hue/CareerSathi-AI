import { t, isHindi } from '../core/i18n.js';
import { getState, addFamilyNote, removeFamilyNote, toggleComparison } from '../core/store.js';
import { navigate } from '../core/router.js';
import { careers } from '../data/careers.js';

export function renderParent(container) {
  const state = getState();
  const hi = isHindi();
  const results = state.assessment.results || [];
  const topResults = results.slice(0, 5);

  if (topResults.length === 0) {
    container.innerHTML = `
      <div class="page-container">
        <div class="empty-page">
          <div class="empty-icon"><i data-lucide="clipboard-list"></i></div>
          <h2>${t('noAssessmentYet')}</h2>
          <p>${hi ? 'छात्र द्वारा आकलन पूरा करने पर करियर विकल्प यहां दिखाई देंगे' : 'Career options will appear here once the student completes the assessment'}</p>
          <button class="btn-primary btn-lg" id="go-assessment">
            <i data-lucide="arrow-right"></i> ${t('startAssessment')}
          </button>
        </div>
      </div>
    `;
    document.getElementById('go-assessment').addEventListener('click', () => navigate('assessment'));
    return;
  }

  const notesHTML = state.familyNotes.length > 0
    ? state.familyNotes.map((note) => `
      <div class="note-item">
        <p>${note.text}</p>
        <span class="note-time">${note.timestamp}</span>
        <button class="note-remove" data-note-id="${note.id}"><i data-lucide="trash-2"></i></button>
      </div>
    `).join('')
    : `<p class="empty-state">${hi ? 'अभी कोई नोट नहीं' : 'No notes yet'}</p>`;

  container.innerHTML = `
    <div class="page-container">
      <div class="page-header">
        <h1><i data-lucide="users"></i> ${t('parentDashboard')}</h1>
        <p>${hi ? 'करियर विकल्पों को समझें और अपने बच्चे के साथ निर्णय लें' : 'Understand career options and make decisions together with your child'}</p>
        <div class="demo-inline"><i data-lucide="info"></i> ${t('demoContent')}</div>
      </div>

      <div class="parent-layout">
        <div class="parent-main">
          <div class="parent-careers">
            ${topResults.map((r) => renderParentCareerCard(r, hi)).join('')}
          </div>
        </div>

        <div class="parent-sidebar">
          <div class="card sidebar-card">
            <h3><i data-lucide="messages-square"></i> ${t('familyNotes')}</h3>
            <div class="notes-list" id="notes-list">
              ${notesHTML}
            </div>
            <div class="note-input">
              <textarea id="note-text" placeholder="${hi ? 'अपना नोट लिखें...' : 'Write your note...'}"></textarea>
              <button class="btn-primary btn-sm" id="add-note">
                <i data-lucide="plus"></i> ${t('addNote')}
              </button>
            </div>
          </div>

          <div class="card sidebar-card">
            <h3><i data-lucide="file-text"></i> ${t('discussionSummary')}</h3>
            <p class="sidebar-info">${hi ? 'छात्र और अभिभावक एक साथ निर्णय लेने के लिए करियर तुलना का उपयोग कर सकते हैं' : 'Use the career comparison tool to make decisions together'}</p>
            <button class="btn-outline btn-block" id="go-compare">
              <i data-lucide="git-compare"></i> ${t('nav_compare')}
            </button>
          </div>
        </div>
      </div>
    </div>
  `;

  container.querySelectorAll('[data-action="compare"]').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleComparison(btn.getAttribute('data-career-id'));
    });
  });

  container.querySelectorAll('[data-action="roadmap"]').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      import('../core/store.js').then(({ setRoadmapCareer }) => {
        setRoadmapCareer(btn.getAttribute('data-career-id'));
        navigate('roadmap');
      });
    });
  });

  container.querySelectorAll('.note-remove').forEach((btn) => {
    btn.addEventListener('click', () => {
      removeFamilyNote(Number(btn.getAttribute('data-note-id')));
    });
  });

  document.getElementById('add-note').addEventListener('click', () => {
    const textarea = document.getElementById('note-text');
    const text = textarea.value.trim();
    if (text) {
      addFamilyNote(text);
      textarea.value = '';
    }
  });

  document.getElementById('go-compare').addEventListener('click', () => navigate('compare'));
}

function renderParentCareerCard(result, hi) {
  const career = result.career;
  const name = hi ? career.nameHi : career.name;
  const sector = hi ? career.sectorHi : career.sector;
  const desc = hi ? career.descriptionHi : career.description;
  const skills = (hi ? career.skillsHi : career.skills).join(', ');
  const certs = career.certifications.join(', ');
  const pathways = career.careerPathways[0];
  const safetyInfo = getSafetyInfo(career, hi);

  return `
    <div class="parent-career-card">
      <div class="parent-card-header">
        <div class="parent-card-icon"><i data-lucide="${career.icon}"></i></div>
        <div>
          <h3>${name}</h3>
          <span class="career-sector">${sector}</span>
        </div>
        <div class="match-badge">${result.matchPercent}% ${t('matchPercent')}</div>
      </div>
      <p class="parent-card-desc">${desc}</p>
      <div class="parent-card-grid">
        <div class="parent-info-item">
          <span class="info-label"><i data-lucide="wallet"></i> ${t('courseFee')}</span>
          <span class="info-value">${career.courseCost}</span>
        </div>
        <div class="parent-info-item">
          <span class="info-label"><i data-lucide="clock"></i> ${t('courseDuration')}</span>
          <span class="info-value">${career.courseDuration}</span>
        </div>
        <div class="parent-info-item">
          <span class="info-label"><i data-lucide="target"></i> ${t('requiredSkills')}</span>
          <span class="info-value">${skills}</span>
        </div>
        <div class="parent-info-item">
          <span class="info-label"><i data-lucide="award"></i> ${t('certifications')}</span>
          <span class="info-value">${certs}</span>
        </div>
        <div class="parent-info-item">
          <span class="info-label"><i data-lucide="trending-up"></i> ${t('careerPathways')}</span>
          <span class="info-value">${pathways}</span>
        </div>
        <div class="parent-info-item">
          <span class="info-label"><i data-lucide="shield"></i> ${t('safetyConsiderations')}</span>
          <span class="info-value">${safetyInfo}</span>
        </div>
      </div>
      <div class="parent-card-actions">
        <button class="btn-outline btn-sm" data-action="compare" data-career-id="${career.id}">
          <i data-lucide="git-compare"></i> ${t('compare')}
        </button>
        <button class="btn-primary btn-sm" data-action="roadmap" data-career-id="${career.id}">
          <i data-lucide="map"></i> ${t('nav_roadmap')}
        </button>
      </div>
    </div>
  `;
}

function getSafetyInfo(career, hi) {
  const safetyMap = {
    electrician: hi ? 'उचित सुरक्षा उपकरण आवश्यक; प्रशिक्षित पेशेवरों के तहत प्रशिक्षण' : 'Proper safety gear required; training under certified professionals',
    plumber: hi ? 'आमतौर पर सुरक्षित; शारीरिक मेहनत शामिल' : 'Generally safe; involves physical labor',
    tailoring: hi ? 'सुरक्षित इनडोर कार्य; कम शारीरिक जोखिम' : 'Safe indoor work; low physical risk',
    beauty: hi ? 'सुरक्षित इनडोर कार्य; स्वच्छता मानक आवश्यक' : 'Safe indoor work; hygiene standards required',
    'web-dev': hi ? 'सुरक्षित रिमोट कार्य संभव; घर से काम का विकल्प' : 'Safe remote work possible; work-from-home option',
    'data-entry': hi ? 'सुरक्षित इनडोर डेस्क कार्य' : 'Safe indoor desk work',
    automobile: hi ? 'उचित वेंटिलेशन और सुरक्षा उपकरण आवश्यक' : 'Proper ventilation and safety gear required',
    healthcare: hi ? 'संक्रमण नियंत्रण प्रोटोकॉल आवश्यक; उचित प्रशिक्षण आवश्यक' : 'Infection control protocols required; proper training needed',
    agriculture: hi ? 'बाहरी कार्य; उचित सुरक्षा उपकरण की सलाह' : 'Outdoor work; proper safety equipment advised',
    electronics: hi ? 'सुरक्षित इनडोर कार्य; तार के संपर्क में सावधानी' : 'Safe indoor work; caution with electrical components',
    'food-processing': hi ? 'खाद्य सुरक्षा मानक आवश्यक; स्वच्छ वातावरण' : 'Food safety standards required; clean environment',
    carpentry: hi ? 'उचित सुरक्षा उपकरण आवश्यक; शारीरिक मेहनत शामिल' : 'Proper safety gear required; involves physical labor',
    retail: hi ? 'सुरक्षित इनडोर कार्य; लंबे समय तक खड़े रहना' : 'Safe indoor work; long standing hours',
    'graphic-design': hi ? 'सुरक्षित इनडोर रचनात्मक कार्य; रिमोट विकल्प' : 'Safe indoor creative work; remote option',
    'banking-bpo': hi ? 'सुरक्षित इनडोर डेस्क कार्य; निश्चित कार्य समय' : 'Safe indoor desk work; fixed working hours',
  };
  return safetyMap[career.id] || (hi ? 'सामान्य सुरक्षा दिशानिर्देश लागू' : 'General safety guidelines apply');
}
