import { t, isHindi } from '../core/i18n.js';
import { getState, toggleComparison, setComparison } from '../core/store.js';
import { careers } from '../data/careers.js';
import { navigate } from '../core/router.js';

let chartRefs = {};

export function renderCompare(container) {
  const state = getState();
  const hi = isHindi();
  const selectedIds = state.comparison;
  const selectedCareers = selectedIds.map((id) => careers.find((c) => c.id === id)).filter(Boolean);
  const unselected = careers.filter((c) => !selectedIds.includes(c.id));

  container.innerHTML = `
    <div class="page-container">
      <div class="page-header">
        <h1><i data-lucide="git-compare"></i> ${t('careerComparison')}</h1>
        <p>${t('selectUpToThree')}</p>
      </div>

      <div class="compare-selector">
        <label>${t('addCareer')}</label>
        <div class="selector-dropdown">
          <select id="career-selector">
            <option value="">${hi ? 'करियर चुनें' : 'Select a career'}</option>
            ${unselected.map((c) => `<option value="${c.id}">${hi ? c.nameHi : c.name}</option>`).join('')}
          </select>
        </div>
      </div>

      ${selectedCareers.length > 0 ? renderComparisonTable(selectedCareers, hi) : `
        <div class="empty-page">
          <div class="empty-icon"><i data-lucide="git-compare"></i></div>
          <p>${t('noCareersSelected')}</p>
        </div>
      `}

      ${selectedCareers.length >= 2 ? `
        <div class="compare-charts">
          <div class="chart-card">
            <h3>${t('costComparison')}</h3>
            <canvas id="cost-chart" height="200"></canvas>
          </div>
          <div class="chart-card">
            <h3>${t('durationComparison')}</h3>
            <canvas id="duration-chart" height="200"></canvas>
          </div>
        </div>
      ` : ''}
    </div>
  `;

  const selector = document.getElementById('career-selector');
  if (selector) {
    selector.addEventListener('change', () => {
      const id = selector.value;
      if (id) {
        toggleComparison(id);
      }
    });
  }

  container.querySelectorAll('[data-action="remove"]').forEach((btn) => {
    btn.addEventListener('click', () => {
      toggleComparison(btn.getAttribute('data-career-id'));
    });
  });

  if (selectedCareers.length >= 2) {
    setTimeout(() => renderCharts(selectedCareers, hi), 50);
  }
}

function renderComparisonTable(selectedCareers, hi) {
  const cols = selectedCareers.length;
  const rows = [
    { label: t('sector'), get: (c) => hi ? c.sectorHi : c.sector },
    { label: t('courseDuration'), get: (c) => c.courseDuration },
    { label: t('estimatedCost'), get: (c) => c.courseCost },
    { label: t('requiredSkills'), get: (c) => (hi ? c.skillsHi : c.skills).join(', ') },
    { label: t('certifications'), get: (c) => c.certifications.join(', ') },
    { label: t('learningModes'), get: (c) => c.learningModes.join(', ') },
    { label: t('careerPathways'), get: (c) => c.careerPathways[0] },
    { label: t('salaryRange'), get: (c) => c.salaryRange },
    { label: t('futureOpportunities'), get: (c) => c.futureOpportunities },
  ];

  return `
    <div class="comparison-table-wrapper">
      <table class="comparison-table">
        <thead>
          <tr>
            <th class="label-col"></th>
            ${selectedCareers.map((c) => `
              <th>
                <div class="compare-header">
                  <div class="compare-icon"><i data-lucide="${c.icon}"></i></div>
                  <span>${hi ? c.nameHi : c.name}</span>
                  <button class="remove-btn" data-action="remove" data-career-id="${c.id}">
                    <i data-lucide="x"></i>
                  </button>
                </div>
              </th>
            `).join('')}
          </tr>
        </thead>
        <tbody>
          ${rows.map((row, idx) => `
            <tr class="${idx % 2 === 0 ? 'even' : 'odd'}">
              <td class="label-col">${row.label}</td>
              ${selectedCareers.map((c) => `<td>${row.get(c)}</td>`).join('')}
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;
}

async function renderCharts(selectedCareers, hi) {
  const { Chart, registerables } = await import('chart.js');
  Chart.register(...registerables);

  Object.values(chartRefs).forEach((c) => c.destroy());
  chartRefs = {};

  const labels = selectedCareers.map((c) => hi ? c.nameHi : c.name);
  const costs = selectedCareers.map((c) => c.courseCostValue);
  const durations = selectedCareers.map((c) => c.courseDurationWeeks);

  const costCtx = document.getElementById('cost-chart');
  if (costCtx) {
    chartRefs.cost = new Chart(costCtx, {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          label: t('courseFee'),
          data: costs,
          backgroundColor: ['#1a3a6e', '#7c3aed', '#06b6d4'],
          borderRadius: 8,
        }],
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: {
          y: { beginAtZero: true, ticks: { callback: (v) => '₹' + v } },
        },
      },
    });
  }

  const durationCtx = document.getElementById('duration-chart');
  if (durationCtx) {
    chartRefs.duration = new Chart(durationCtx, {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          label: t('duration') + ' (weeks)',
          data: durations,
          backgroundColor: ['#1a3a6e', '#7c3aed', '#06b6d4'],
          borderRadius: 8,
        }],
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true } },
      },
    });
  }
}
